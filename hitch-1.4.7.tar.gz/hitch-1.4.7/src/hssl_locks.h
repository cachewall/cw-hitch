/*-
 * Copyright (c) 2015-2016 Varnish Software
 * All rights reserved.
 *
 * Author: Martin Blix Grydeland <martin@varnish-software.com>
 */

void HSSL_Locks_Init(void);
